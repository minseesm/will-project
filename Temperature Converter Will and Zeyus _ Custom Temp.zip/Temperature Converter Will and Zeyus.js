/* 
	Title: Kelvin Temperature Converter for CNN - Will and Zeyus
	Program Summary: This program aims to provide the CNN Weather Center with the ability to convert temperature between various units of measurement. Our webpage enables a seamless UI/UX experience for the user of the website.
	Important (KEY) Program Elemnts Used: Variables, Data Types, IF statements, and Arithmetic Operators when it comes to JavaScript. Basic HTML/CSS syntax was utilized in order to create an excellent web experience.
*/ 

//Beginning Of Program




// Variable Declarations

let kelvin = 250; // static value for now. Will be updated to a dynamic value later.

let celsius = kelvin - 273; // static value for now. Will be updated to a dynamic value later.

let fahrenheit = celsius * (9/5) + 32; // static value for now. Will be updated to a dynamic value later.

let todayAvg = 0.0; // Variable for today's average temperature.




// Functions Declarations

// processWeatherData function is defined to input weather informations getted from above website to decleared variables previously.

function processWeatherData(response) {

  // input weather informations getted from above website to 'days' variable
  var days = response.days; 

  // print all weather imformations on console for just checking
  for (var i=0;i<days.length;i++) {

    console.log(days[i].datetime+": tempmax="+days[i].tempmax+", tempmin="+days[i].tempmin);

  }

  // here, data value of days[1] is today's one.
  // extracting min, max, avg temperatures.

  let todayMax = days[0].tempmax;

  let todayMin = days[0].tempmin;

  todayAvg = Math.round((todayMax + todayMin) / 2);

}




// setTemperature function is defined to change values for thermometer view

function setTemperature(averageTempToday, unit) {

  let height = averageTempToday;

  height = parseFloat(height);      // if get the values from prompt, the value type will be character type. So, it have to change the type using parseFloat() char to float

  if (unit == "K") height - 273;    // kelvin unit has too big number. so, scaled by subtract 273;

  if (height < -30) height = 0;     // the thermometer height range should be in 0 % to 100 %.

  if (height > 70) height = 70;     // So, we neet to set limited height size.

  temperature.style.height = (height + 30) + "%";

  temperature.dataset.value = averageTempToday + unit;

}




// convertCelToFah function is defined to convert Celsius unit to Fahrenheit unit

function convertCelToFah (celsiusUnit) {

  return celsiusUnit * (9/5) + 32;

}




// askForTempType function is defined for using prompt to get user's needs and convert unit depending on needs.

function askForTempType () {

  let region = prompt('Welcome today\'s Weather \nSelect the temperature type do you want \n\n USA -> °F \n CANADA -> °C');  

  if (region == "USA" || region == "usa") { // if user's input data is USA, convert our Celsius unit data to Fahrenheit unit

    setTemperature(convertCelToFah(todayAvg), "°F"); // using setTemperature function set thermometer's value and height

  }
  
  else if (region == "CANADA" || region == "canada" || region == "Canada") { // if user's input data is CANADA, we don't need to change unit
  
    setTemperature(todayAvg, "°C");  // using setTemperature function set thermometer's value and height

  
  }

  else if (region === null) {}  // if user clicked 'cancle' button, anything isn't change.
  
  else { // if user's input data is not both usa and canada, show alert and ask again.
  
    alert('Wrong input. Please input \'USA\' or \'CANADA\'');

    askForTempType ();
    
  }

}




// changeTempValue function is defined to open prompt, get value, change temperature values when cliked customize button.

function changeTempValue() {

  let convertType = prompt('What do you want to convert type? \n\n(input \'1\') Kelvin to Celsious and Fahrenheit \n(input \'2\') Celsious to Kelvin and Fahrenheit \n(input \'3\') Fahrenheit to Kelvin and Celsious'); 

  if (convertType == 1) {

    kelvin = prompt('Please input temperature value which you want to convert');
    
    celsius = parseFloat(kelvin) - 273;   // if get the values from prompt, the value type will be character type. So, it have to change the type using parseFloat() char to float

    fahrenheit = celsius * (9/5) + 32; 

    setTemperature(kelvin, "K"); 

  }
  else if (convertType == 2) {

    celsius = prompt('Please input temperature value which you want to convert');

    kelvin = parseFloat(celsius) + 273; // if get the values from prompt, the value type will be character type. So, it have to change the type using parseFloat() char to float

    fahrenheit = celsius * (9/5) + 32; 

    setTemperature(celsius, "°C"); // The thermometer's value and height also need to change.

  }
  else if (convertType == 3) {

    fahrenheit = prompt('Please input temperature value which you want to convert');

    celsius = (fahrenheit - 32) * (5/9);

    kelvin = celsius + 273;

    setTemperature(fahrenheit, "°F"); // The thermometer's value and height also need to change.

  }
  else if (region === null) {}  // if user clicked 'cancle' button, anything isn't change.

  else { // if user's input data is not range in 1 to 3, show alert and ask again.
  
    alert('Wrong input. Please input the range in 1 to 3');

    changeTempValue();

  }

  // Change the values on HTML

  document.getElementById('kelvin').innerText = parseFloat(kelvin).toFixed(2) + " K ";

  document.getElementById('celsius').innerText = parseFloat(celsius).toFixed(2) + " °C ";

  document.getElementById('fahrenheit').innerText = parseFloat(fahrenheit).toFixed(2) + " °F ";

}





// From here, MAIN

// Firstly, we need to get today's weather temperature information from https://weather.visualcrossing.com
// After getting informations, store in variables and open prompt for asking unit type that user want.

// Due to the asynchronous nature of JavaScript, we inserted the code we wrote in order in the referenced API code.
// The askForTempType function has to call after this fetch finished.

fetch("https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/north%20vancouver?unitGroup=metric&include=alerts%2Ccurrent%2Cdays%2Chours%2Cevents&key=QJ4MMTTUBT39MAWTZLFYVVDG6&contentType=json",
{

  method: 'GET', 

  headers: {},

})

.then(response => {

  if (!response.ok) {

    throw response; //check the http response code and if isn't ok then throw the response as an error

  }            

  return response.json();   //parse the result as JSON

})

.then(response => {   //response now contains parsed JSON ready for use

  processWeatherData(response);   //call processWeatherData function



  // we get the today's temperature informations (max, min, avg) via fatch, but these are Celsius units.
  // So, we need to convert unit depending on user's needs.
  // we just use average value for converting to other unit.

  askForTempType();    //call askForTempType function

  kelvin = (todayAvg + 273); 

  celsius = kelvin - 273;

  fahrenheit = celsius * (9/5) + 32; 



  // calculated each unit value be inputed in each <span> tags that are distinguished by each ID on HTML
  // .toFixed(2) is to display only two decimal places.

  document.getElementById('kelvin').innerText = kelvin.toFixed(2) + " K ";

  document.getElementById('celsius').innerText = celsius.toFixed(2) + " °C ";

  document.getElementById('fahrenheit').innerText = fahrenheit.toFixed(2) + " °F ";



  // End user interface.

  alert("Thank You For Using CNN For All Your Weather Needs");

  console.log("Thank You For Using CNN For All Your Weather Needs");

})

.catch((errorResponse) => {

  if (errorResponse.text) { //additional error information

    errorResponse.text().then( errorMessage => {})  //errorMessage now returns the response body which includes the full error message

  } else { }  //no additional error information 

});



// if user clicked the customize button, call changeTempValue function open prompt, get value, change temperature values.

document.getElementById('custom').addEventListener('click', changeTempValue );




// Ending Of Program


/* NOTES:
    Ideas for expansion located in the learning document 
    New JavaScript tools on W3 Schools 
    Variables for other conditions like the wind
    Another type of conversion could be worked on, such as Celsius to Newtons
    Utilize HTML & CSS
    UIUX: Title, Welcome, Intro, Explanation, Re-iterate input, output, Thanks
    Look at actual CNN weather page
    Watch CodeCademy video
    aski art text generstior, art for console.
    https://codepen.io/Arkellys/pen/rgpNBK - Link to cool thermometer
    when person comes into website, they can be asked in a css input box. are you in canada or usa. select below. if they are from canada, it shows clesius, if canada it shows celsisus.
*/
